<template>

</template>

<script>
    export default {
        name: "Main"
    }
</script>

<style scoped>

</style>