<template>
    
</template>

<script>
    export default {
        name: "Chart"
    }
</script>

<style scoped>

</style>