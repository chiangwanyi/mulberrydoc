import Vue from 'vue'
import VueRouter, {RouteConfig} from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes: Array<RouteConfig> = [
    {
        path: '/',
        name: 'Home',
        component: Home
    },
    {
        path: '/doc',
        name: 'Doc',
        component: () => import('../views/editor/Doc.vue')
    },
    {
        path: '/markdown',
        name: 'Markdown',
        component: () => import('../views/editor/Markdown.vue')
    },
    {
        path: '/chart',
        name: 'Chart',
        component: () => import('../views/editor/Chart.vue')
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
